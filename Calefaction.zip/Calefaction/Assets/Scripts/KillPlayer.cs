﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class KillPlayer : MonoBehaviour {

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            //HotAndCold.instance.TurnCold();
           // Destroy(other.gameObject);//destorys the player
            Debug.Log("Player Dead - reload scene");
            //instance the audiomanager and play the sound
            //AudioManager.instance.PlaySound("thud");
            //ReloadScene();
            StartCoroutine(ReloadScene());
        }
    }
    private IEnumerator ReloadScene()
    {
        // waits for a split second and then restarts the scene (needs to be changed later to bring up a menu)
        yield return new WaitForSeconds(0.1f);
        Scene scene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(scene.name);
    }
}
