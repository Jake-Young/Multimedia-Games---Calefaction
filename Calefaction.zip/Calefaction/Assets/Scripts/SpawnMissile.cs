﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnMissile : MonoBehaviour {

    public Vector3 minDectectionRange, maxDetectionRange;
    public GameObject Missile;
    bool IsMissileOut = false;
    
	// Update is called once per frame
	void Update () {
       
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        //only fires missile if player is in circle collision box
        if (IsMissileOut == false && collision.tag == "Player")
        {
            //if no missile out launches a missile after a delay
            if (Missile != null)
            {
                IsMissileOut = true;
                Invoke("LaunchMissile", 2f);
            }
        }
        if (Missile != null && IsMissileOut == true)
        {
            IsMissileOut = false;
        }
    }
    void OnTriggerEnter2D(Collider2D other)
    {
       



    }

    public void LaunchMissile()
    {
        Instantiate(Missile, transform.position, Quaternion.Euler(0, 0, 0));
        Debug.Log("Made A collision");
    }

}
