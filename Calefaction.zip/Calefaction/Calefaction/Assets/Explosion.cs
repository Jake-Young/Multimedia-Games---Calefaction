﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Explosion : MonoBehaviour {

    public AudioClip MissileExplodingSound; // sound that plays when missile explodes
    private AudioSource MissileExploding;

    void OnTriggerEnter2D(Collider2D collider)
    {

        if (collider.tag == "Player") //(or crates?)
        {
            Vector2 target = collider.gameObject.transform.position;
            Vector2 explosionposition = gameObject.transform.position;
            Vector2 direction = 40f * (target - explosionposition);
            //force of the explosion

            collider.gameObject.GetComponent<Rigidbody2D>().AddForce(direction);
            Invoke("DestoryExplosion", 0.20f);
        }

    }

    private void DestoryExplosion()
    {
        Destroy(gameObject);
    }
}
